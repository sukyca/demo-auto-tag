ALTER TABLE {database}.{schema}.{table_name}
DROP COLUMN {column_names};