import os
import time
import logging
import snowflake.connector

import utils

conn_details = {
    'user': os.getenv('USER'),
    'password': os.getenv('PASSWORD'),
    'account': os.getenv('ACCOUNT'),
}

# conn_details = {
#     'user': 'ahrelja',
#     'password': 'Iolap1go!',
#     'account': 'kv94459.us-east-2.aws',
# }

logger = utils.get_logger(__file__)

logging.getLogger('snowflake.connector').setLevel(logging.WARNING)


def get_connection(conn_update=None):
    if conn_update:
        conn_details.update(conn_update)
    return snowflake.connector.connect(**conn_details)


def execute_query(query, conn_update=None, retry_max=3, retry_delay=3):
    connection = get_connection(conn_update)
    cursor = connection.cursor()
    result = None
    retry_num = 0
    
    while result is None and retry_num < retry_max:
        try:
            cursor.execute(query)
            result = cursor.fetchall()
        except Exception as e:
            retry_num += 1
            logger.error("Snowflake query '{}' execution failed. Trying again ({}/{})."
                         "\nError message: {}".format(query, retry_num+1, retry_max, e))
            time.sleep(retry_num * retry_delay)
    
    cursor.close()
    connection.close()
    if result is None:
        return []
    return result
